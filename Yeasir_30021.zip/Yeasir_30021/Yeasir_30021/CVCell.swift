//
//  CVCell.swift
//  Yeasir_30021
//
//  Created by bjit on 20/12/22.
//

import UIKit

class CVCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
}
